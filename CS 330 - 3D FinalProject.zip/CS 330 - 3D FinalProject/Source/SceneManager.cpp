///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ============
// manage the preparing and rendering of 3D scenes - textures, materials, lighting
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager *pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();

	// initialize the texture collection
	for (int i = 0; i < 16; i++)
	{
		m_textureIDs[i].tag = "/0";
		m_textureIDs[i].ID = -1;
	}

	m_loadedTextures = 0;
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;

	// destroy the created OpenGL textures
	DestroyGLTextures();
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glDeleteTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(bFound);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationZ * rotationY * rotationX * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{

	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value(
				"material.diffuseColor",
				material.diffuseColor);

			m_pShaderManager->setVec3Value(
				"material.specularColor",
				material.specularColor);

			m_pShaderManager->setFloatValue(
				"material.shininess",
				material.shininess);
		}
	}
}
/**************************************************************
* DefineObjectMaterials()
* 
* This method is used for defining the materials used
* by the objects in the 3D scene.
**************************************************************/
void SceneManager::DefineObjectMaterials()
{
	// material used for the wooden desk
	OBJECT_MATERIAL woodMaterial;
	woodMaterial.diffuseColor = glm::vec3(1.0f, 1.0f, 1.0f);
	woodMaterial.specularColor = glm::vec3(0.10f, 0.10f, 0.10f);
	woodMaterial.shininess = 2.0f;
	woodMaterial.tag = "woodMaterial";

	m_objectMaterials.push_back(woodMaterial);

	// material used for the plastic objects (ex: monitor & stand)
	OBJECT_MATERIAL plasticMaterial;
	plasticMaterial.diffuseColor = glm::vec3(1.0f, 1.0f, 1.0f);
	plasticMaterial.specularColor = glm::vec3(0.35f, 0.35f, 0.35f);
	plasticMaterial.shininess = 8.0f;
	plasticMaterial.tag = "plasticMaterial";

	m_objectMaterials.push_back(plasticMaterial);

	// material used for the monitor screen
	OBJECT_MATERIAL screenMaterial;
	screenMaterial.diffuseColor = glm::vec3(1.0f, 1.0f, 1.0f);
	screenMaterial.specularColor = glm::vec3(0.08f, 0.08f, 0.08f);
	screenMaterial.shininess = 1.0f;
	screenMaterial.tag = "screenMaterial";

	m_objectMaterials.push_back(screenMaterial);

	// material used for the mug
	OBJECT_MATERIAL ceramicMaterial;
	ceramicMaterial.diffuseColor = glm::vec3(1.0f, 1.0f, 1.0f);
	ceramicMaterial.specularColor = glm::vec3(0.40f, 0.40f, 0.40f);
	ceramicMaterial.shininess = 8.0f;
	ceramicMaterial.tag = "ceramicMaterial";

	m_objectMaterials.push_back(ceramicMaterial);

	// material used for the hacky sack
	OBJECT_MATERIAL fabricMaterial;
	fabricMaterial.diffuseColor = glm::vec3(1.0f, 1.0f, 1.0f);
	fabricMaterial.specularColor = glm::vec3(0.05f, 0.05f, 0.05f);
	fabricMaterial.shininess = 1.0f;
	fabricMaterial.tag = "fabricMaterial";

	m_objectMaterials.push_back(fabricMaterial);
}

/**************************************************************
* SetupSceneLights()
* 
* This method is used for setting up the light sources
* used in the 3D scene.
**************************************************************/
void SceneManager::SetupSceneLights()
{
	// enable custom lighting for the scene
	m_pShaderManager->setBoolValue(g_UseLightingName, true);

	// soft fill light to keep the objects visible from all sides
	m_pShaderManager->setVec3Value(
		"directionalLight.direction",
		0.2f, -1.0f, -0.4f);

	m_pShaderManager->setVec3Value(
		"directionalLight.ambient",
		0.10f, 0.10f, 0.10f);

	m_pShaderManager->setVec3Value(
		"directionalLight.diffuse",
		0.18f, 0.18f, 0.18f);

	m_pShaderManager->setVec3Value(
		"directionalLight.specular",
		0.05f, 0.05f, 0.05f);

	m_pShaderManager->setBoolValue(
		"directionalLight.bActive",
		true);

	// main white point light above the front left side
	m_pShaderManager->setVec3Value(
		"pointLights[0].position",
		-5.0f, 7.0f, 6.0f);

	m_pShaderManager->setVec3Value(
		"pointLights[0].ambient",
		0.03f, 0.03f, 0.03f);

	m_pShaderManager->setVec3Value(
		"pointLights[0].diffuse",
		0.65f, 0.65f, 0.65f);

	m_pShaderManager->setVec3Value(
		"pointLights[0].specular",
		0.25f, 0.25f, 0.25f);

	m_pShaderManager->setBoolValue(
		"pointLights[0].bActive",
		true);

	// blue point light behind the right side of the scene
	m_pShaderManager->setVec3Value(
		"pointLights[1].position",
		5.0f, 6.0f, -4.0f);

	m_pShaderManager->setVec3Value(
		"pointLights[1].ambient",
		0.02f, 0.03f, 0.05f);

	m_pShaderManager->setVec3Value(
		"pointLights[1].diffuse",
		0.16f, 0.22f, 0.35f);

	m_pShaderManager->setVec3Value(
		"pointLights[1].specular",
		0.10f, 0.16f, 0.28f);

	m_pShaderManager->setBoolValue(
		"pointLights[1].bActive",
		true);
}



/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/

/***********************************************************
* LoadSceneTextures()
* 
* This method is used for loading the textures used
* in the 3D scene.
************************************************************/
void SceneManager::LoadSceneTextures()
{
	bool bReturn = false;

	// load the wood texture used for the desk 
	bReturn = CreateGLTexture(
		"textures/wood.jpg",
		"wood");

	// load the black plastic texture used for the monitor
	bReturn = CreateGLTexture(
		"textures/blackPlastic.jpg",
		"blackPlastic");

	// load the image used for the monitor screen
	bReturn = CreateGLTexture(
		"textures/screen.jpg",
		"screen");

	// load the multicolor texture used for the hacky sack
	bReturn = CreateGLTexture(
		"textures/hackySack.jpg",
		"hackySack");

	// bind the loaded textures to the available slots
	BindGLTextures();
}

/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	// load the textures for the 3D scene
	LoadSceneTextures();

	// define the materials used by the scene objects
	DefineObjectMaterials();

	// add the light sources for the scene
	SetupSceneLights();

	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene
	
	// load the meshes used to create the monitor, monitor stand, desk, and other objects
	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadTorusMesh(0.06f);
	m_basicMeshes->LoadSphereMesh();
	m_basicMeshes->LoadTaperedCylinderMesh();
}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by 
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	RenderDesk();
	RenderMonitor();
	RenderKeyboard();
	RenderMouse();
	RenderMug();
	RenderHackySack();
}

/***********************************************************
 *  RenderDesk()
 *
 *  Draw the wooden desk used as the base of the scene
 ***********************************************************/
void SceneManager::RenderDesk()
{
	// brown plane representing the wooden desk surface 
	SetTransformations(
		glm::vec3(20.0f, 1.0f, 10.0f),
		0.0f,
		0.0f,
		0.0f,
		glm::vec3(0.0f, 0.0f, 0.0f));

	// apply the wood material and texture to the desk
	SetShaderMaterial("woodMaterial");
	SetShaderTexture("wood");
	SetTextureUVScale(5.0f, 5.0f);

	m_basicMeshes->DrawPlaneMesh();
}

/***********************************************************
 *  RenderMonitor()
 *
 *  Draw the monitor, screen, support, and curved base
 ***********************************************************/
void SceneManager::RenderMonitor()
{
	// monitor housing created from a flattened box
	SetTransformations(
		glm::vec3(7.50f, 2.80f, 0.30f),
		0.0f,
		0.0f,
		0.0f,
		glm::vec3(0.0f, 3.00f, 0.00f));

	// apply the dark texture to the monitor housing
	SetShaderMaterial("plasticMaterial");
	SetShaderTexture("blackPlastic");
	SetTextureUVScale(2.0f, 1.0f);

	m_basicMeshes->DrawBoxMesh();


	// thin box representing the monitor's screen
	SetTransformations(
		glm::vec3(7.25f, 2.55f, 0.05f),
		0.0f,
		0.0f,
		0.0f,
		glm::vec3(0.0f, 3.0f, 0.18f));

	SetTextureUVScale(1.0f, 1.0f);

	// apply black plastic to the outside edges of the screen
	SetShaderMaterial("plasticMaterial");
	SetShaderTexture("blackPlastic");

	m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::box_back);
	m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::box_bottom);
	m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::box_left);
	m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::box_right);
	m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::box_top);

	// apply the screen image to the front
	SetShaderMaterial("screenMaterial");
	SetShaderTexture("screen");

	m_basicMeshes->DrawBoxMeshSide(ShapeMeshes::box_front);


	// cylinder connecting the monitor housing to the half-torus base.
	SetTransformations(
		glm::vec3(0.25f, 1.55f, 0.25f),
		0.0f,
		0.0f,
		0.0f,
		glm::vec3(0.0f, 0.08f, -0.08f));

	// apply the monitor texture to the cylinder support
	SetShaderMaterial("plasticMaterial");
	SetShaderTexture("blackPlastic");
	SetTextureUVScale(1.0f, 2.0f);

	m_basicMeshes->DrawCylinderMesh();


	// curved monitor base using a half-torus
	SetTransformations(
		glm::vec3(1.65f, 2.5f, 1.00f),
		-8.0f,
		180.0f,
		0.0f,
		glm::vec3(0.0f, 0.12f, 1.15f));

	// apply the monitor texture to the curved base
	SetShaderMaterial("plasticMaterial");
	SetShaderTexture("blackPlastic");
	SetTextureUVScale(1.0f, 1.0f);

	m_basicMeshes->DrawHalfTorusMesh();
}

/***********************************************************
 *  RenderKeyboard()
 *
 *  Draw the keyboard in front of the monitor
 ***********************************************************/
void SceneManager::RenderKeyboard()
{
	// keyboard base
	SetTransformations(
		glm::vec3(5.9f, 0.15f, 1.8f),
		0.0f,
		0.0f,
		0.0f,
		glm::vec3(0.52f, 0.10f, 3.80f));

	SetShaderMaterial("plasticMaterial");
	SetShaderColor(0.18f, 0.18f, 0.18f, 1.0f);

	m_basicMeshes->DrawBoxMesh();

	// main keyboard section
	for (int row = 0; row < 4; row++)
	{
		for (int column = 0; column < 10; column++)
		{
			SetTransformations(
				glm::vec3(0.34f, 0.05f, 0.24f),
				0.0f,
				0.0f,
				0.0f,
				glm::vec3(
					-1.95f + (column * 0.42f),
					0.21f,
					3.27f + (row * 0.33f)));

			SetShaderMaterial("plasticMaterial");
			SetShaderColor(0.10f, 0.10f, 0.10f, 1.0f);

			m_basicMeshes->DrawBoxMesh();
		}
	}

	// numberpad section on the right
	for (int row = 0; row < 4; row++)
	{
		for (int column = 0; column < 3; column++)
		{
			SetTransformations(
				glm::vec3(0.34f, 0.05f, 0.24f),
				0.0f,
				0.0f,
				0.0f,
				glm::vec3(
					2.15f + (column * 0.42f),
					0.21f,
					3.27f + (row * 0.33f)));

			SetShaderMaterial("plasticMaterial");
			SetShaderColor(0.10f, 0.10f, 0.10f, 1.0f);

			m_basicMeshes->DrawBoxMesh();
		}
	}
}

/***********************************************************
*  RenderMouse()
*
*  Draw the mouse to the right of the keyboard
***********************************************************/
void SceneManager::RenderMouse()
{
	// main portion of the mouse
	SetTransformations(
		glm::vec3(0.70f, 0.24f, 0.90f),
		0.0f,
		-12.0f,
		0.0f,
		glm::vec3(4.75f, 0.08f, 3.15f));

	SetShaderMaterial("plasticMaterial");
	SetShaderColor(0.08f, 0.08f, 0.08f, 1.0f);

	m_basicMeshes->DrawHalfSphereMesh();

	// center split on the top of the mouse
	SetTransformations(
		glm::vec3(0.025f, 0.025f, 0.45f),
		0.0f,
		-12.0f,
		0.0f,
		glm::vec3(4.84f, 0.35f, 2.72f));

	SetShaderMaterial("plasticMaterial");
	SetShaderColor(0.16f, 0.16f, 0.16f, 1.0f);

	m_basicMeshes->DrawBoxMesh();

	// scroll wheel
	SetTransformations(
		glm::vec3(0.08f, 0.18f, 0.10f),
		0.0f,
		-12.0f,
		90.0f,
		glm::vec3(4.79f, 0.38f, 2.96f));

	SetShaderMaterial("plasticMaterial");
	SetShaderColor(0.30f, 0.30f, 0.30f, 1.0f);

	m_basicMeshes->DrawCylinderMesh();
}


 /***********************************************************
 *  RenderMug()
 *
 *  Draw the mug and the coaster on the left side of the desk
 ***********************************************************/
void SceneManager::RenderMug()
{
	// coaster
	SetTransformations(
		glm::vec3(0.80f, 0.04f, 0.80f),
		0.0f,
		0.0f,
		0.0f,
		glm::vec3(0.35f, 0.03f, 1.95f));

	SetShaderMaterial("plasticMaterial");
	SetShaderTexture("blackPlastic");
	SetTextureUVScale(1.0f, 1.0f);

	m_basicMeshes->DrawCylinderMesh();

	// outer mug body
	SetTransformations(
		glm::vec3(0.50f, 0.65f, 0.50f),
		0.0f,
		0.0f,
		0.0f,
		glm::vec3(0.35f, 0.08f, 1.95f));

	SetShaderMaterial("ceramicMaterial");
	SetShaderColor(0.12f, 0.12f, 0.12f, 1.0f);

	// draw the bottom and sides, but leave the top open
	m_basicMeshes->DrawCylinderMesh(false, true, true);

	// white inner part of the mug slightly below the top
	SetTransformations(
		glm::vec3(0.40f, 0.50f, 0.40f),
		0.0f,
		0.0f,
		0.0f,
		glm::vec3(0.35f, 0.18f, 1.95f));

	SetShaderMaterial("ceramicMaterial");
	SetShaderColor(0.96f, 0.96f, 0.96f, 1.0f);

	// show the white top and inside walls
	m_basicMeshes->DrawCylinderMesh(true, false, true);

	// mug handle
	SetTransformations(
		glm::vec3(0.10f, 0.40f, 0.12f),
		0.0f,
		0.0f,
		0.0f,
		glm::vec3(0.88f, 0.48f, 1.95f));

	SetShaderMaterial("ceramicMaterial");
	SetShaderColor(0.12f, 0.12f, 0.12f, 1.0f);

	m_basicMeshes->DrawBoxMesh();

	// top part of handle
	SetTransformations(
		glm::vec3(0.22f, 0.08f, 0.12f),
		0.0f,
		0.0f,
		0.0f,
		glm::vec3(0.72f, 0.64f, 1.95f));

	SetShaderMaterial("ceramicMaterial");
	SetShaderColor(0.12f, 0.12f, 0.12f, 1.0f);

	m_basicMeshes->DrawBoxMesh();

	// bottom part of handle
	SetTransformations(
		glm::vec3(0.22f, 0.08f, 0.12f),
		0.0f,
		0.0f,
		0.0f,
		glm::vec3(0.72f, 0.32f, 1.95f));

	SetShaderMaterial("ceramicMaterial");
	SetShaderColor(0.12f, 0.12f, 0.12f, 1.0f);

	m_basicMeshes->DrawBoxMesh();
}

/***********************************************************
*  RenderHackySack()
*
*  Draw the hacky sack on the desk
***********************************************************/
void SceneManager::RenderHackySack()
{
	SetTransformations(
		glm::vec3(0.40f, 0.40f, 0.40f),
		0.0f,
		0.0f,
		0.0f,
		glm::vec3(-1.55f, 0.40f, 1.95f));

	SetShaderMaterial("fabricMaterial");
	SetShaderTexture("hackySack");
	SetTextureUVScale(1.0f, 1.0f);

	m_basicMeshes->DrawSphereMesh();
}